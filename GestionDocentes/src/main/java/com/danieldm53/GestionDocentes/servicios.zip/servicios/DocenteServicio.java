package com.danieldm53.GestionDocentes.servicios;

public class DocenteServicio {
}
