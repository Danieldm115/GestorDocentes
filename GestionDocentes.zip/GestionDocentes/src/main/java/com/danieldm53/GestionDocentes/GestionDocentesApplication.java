package com.danieldm53.GestionDocentes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDocentesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDocentesApplication.class, args);
	}

}
